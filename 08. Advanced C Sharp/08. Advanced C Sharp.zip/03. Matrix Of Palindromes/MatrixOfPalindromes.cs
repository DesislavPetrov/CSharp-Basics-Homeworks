﻿using System;

class MatrixOfPalindromes
{
    static void Main()
    {
        
    }

}